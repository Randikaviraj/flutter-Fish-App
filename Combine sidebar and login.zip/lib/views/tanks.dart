import 'package:flutter/material.dart';

class Tanks extends StatefulWidget {
  @override
  _TanksState createState() => _TanksState();
}

class _TanksState extends State<Tanks> {
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      child: Text("tank"),
    );
  }
}
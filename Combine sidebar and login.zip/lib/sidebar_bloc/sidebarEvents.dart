abstract class SideBarEventS {}

class HomeEvent extends SideBarEventS {}

class MoreEvent extends SideBarEventS {}

class TankEvent extends SideBarEventS {}

class LogOutEvent extends SideBarEventS {}
